import UIKit

struct AnimationEntity {
    var animation: String
    var curve: String
    var force: CGFloat { return CGFloat.random(in: 0.5...2) }
    var duration: CGFloat { return CGFloat.random(in: 0.5...2) }
    var delay: CGFloat
}
