let animations = [AnimationEntity(animation: "shake", curve: "spring", delay: 0.5),
                  AnimationEntity(animation: "pop", curve: "linear", delay: 0.3),
                  AnimationEntity(animation: "morph", curve: "easyIn", delay: 0.2),
                  AnimationEntity(animation: "squeeze", curve: "easyOut", delay: 0.4),
                  AnimationEntity(animation: "wobble", curve: "easyInOut", delay: 0.5)]
