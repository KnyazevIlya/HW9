//
//  ViewController.swift
//  HW9
//
//  Created by admin2 on 10.05.2021.
//

import Spring

class ViewController: UIViewController {

    @IBOutlet var animatedView: SpringView!
    @IBOutlet var animationInfoLabel: UILabel!
    @IBOutlet var animationTriggerButton: SpringButton!
    
    private var animationNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        animatedView.layer.cornerRadius = 20
        animationTriggerButton.layer.masksToBounds = true
        animationTriggerButton.layer.cornerRadius = 20
        animationTriggerButton.setTitle("\(animations[0].animation)", for: .normal)
    }
    
    private func animateView(with animationIndex: Int) {
        animatedView.animation = animations[animationIndex].animation
        animatedView.curve = animations[animationIndex].curve
        animatedView.force = animations[animationIndex].force
        animatedView.duration = animations[animationIndex].duration
        animatedView.delay = animations[animationIndex].delay
        animatedView.animate()
    }
    
    private func setTitles(animationIndex: Int) {
        animationInfoLabel.text = "\(animations[animationIndex].animation)"
        if animationIndex == animations.count - 1 {
            animationTriggerButton.setTitle("Again", for: .normal)
        } else {
            animationTriggerButton.setTitle("Next: \(animations[animationIndex + 1].animation)", for: .normal)
        }
    }

    @IBAction func onClickAnimationTrigger(_ sender: SpringButton) {
        
        animateView(with: animationNumber)
        setTitles(animationIndex: animationNumber)
        if animationNumber == animations.count - 1 {
            animationNumber = 0
        } else {
            animationNumber += 1
        }
    }
    
}

